package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateAccount extends BaseClass {

	// public ChromeDriver driver;

	/*
	 * @Given("launch the Chrome browser") public void browserLaunch() {
	 * WebDriverManager.chromedriver().setup(); driver = new ChromeDriver();
	 * driver.manage().window().maximize(); }
	 * 
	 * @And("load the url") public void loadUrl() {
	 * driver.get("https://login.salesforce.com");
	 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); }
	 */

	@Then("load AppLauncher and navigate till Accounts option")
	public void navAcccount() {
		navigateToAccounts();
	}

	@And("click on NewButton")
	public void clickNewButton() {
		driver.findElement(By.xpath("//a[@title='New']")).click();
		System.out.println("New button clicked successfully");
	}

	@And("Enter the AccountName as (.*)")
	public void enterAccName(String uName) {
		driver.findElement(By.xpath("//label//span[text()='Account Name']/following::input[1]")).sendKeys(uName);
		System.out.println("Name is entered successfully as Nirmalan");
	}

	@And("Enter the Ownership as public")
	public void choseOwership() {
		driver.findElement(By.xpath("//div//span[text()='Ownership']/following::a[1]")).click();

		// Selecting the value for Ownership as Public
		driver.findElement(By.xpath("//div//a[text()='Public']")).click();
		System.out.println("Ownership is entered successfully as Public");
	}

	@Then("click on save button")
	public void clicSave() {
		clickSave();
	}
}
