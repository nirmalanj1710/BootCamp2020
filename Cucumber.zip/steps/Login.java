package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Login extends BaseClass {
	
	/*
	 * @Given("launch the Chrome browser") public void openChromeBrowswer() {
	 * WebDriverManager.chromedriver().setup(); driver = new ChromeDriver();
	 * driver.manage().window().maximize(); }
	 * 
	 * @And("load the url") public void loadApplication() {
	 * driver.get("https://login.salesforce.com");
	 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); }
	 * 
	 * @And("Enter the username as (.*)") public void enterUsername(String uName) {
	 * driver.findElementById("username").sendKeys(uName); }
	 * 
	 * @And("Enter the password as (.*)") public void enterPassword(String
	 * uPassword) { driver.findElementById("password").sendKeys(uPassword); }
	 */

	/*
	 * @Given("enter the username as (.*) and password as (.*)) public void
	 * usernameAndpassword(String uName, String uPassword) {
	 * driver.findElementById("username").sendKeys(uName);
	 * driver.findElementById("password").sendKeys(uPassword); }
	 */
	
	
	
	
/*	@When("click on login button")
	public void clickLoginButton() {
		driver.findElement(By.name("Login")).click();
	}

	@Then("AppLuancher page should be displayed")
	public void AppLauncher() {
		driver.findElement(By.xpath("//*[contains(@class,'slds-icon-waffle_container')]")).click();*/
	}


