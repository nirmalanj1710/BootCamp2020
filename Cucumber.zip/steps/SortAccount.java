package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class SortAccount extends BaseClass {

	@And("click on Accounts")
	public void clickAccNameTab() {
		WebElement accdpdwm = driver.findElement(By.xpath("//a[@title='Accounts']"));
		System.out.println("Accounts clicked successfully");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", accdpdwm);
	}

	@Then("validate the account names are sorted")
	public void sortAccName() {
		WebElement ele = driver.findElement(By.xpath("//a//span[text()='Account Name']"));

		Actions act = new Actions(driver);
		act.moveToElement(ele).click().perform();
		System.out.println("Account Name is sorted in Ascending Order");
	}

}
