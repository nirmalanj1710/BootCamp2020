package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjCommMethods;

public class LoginPage extends ProjCommMethods {

	public LoginPage(RemoteWebDriver driver) {
		this.driver = driver;
		//this.prop = prop;
	}

	public LoginPage enterUsername() {
		// driver.findElementById("username").sendKeys("cypress@testleaf.com");
		WebElement ele = locateElement("id", "username");
		enterValue(ele, "cypress@testleaf.com");
		return this;
	}

	public LoginPage enterPassword() {
		// driver.findElementById("password").sendKeys("Bootcamp@123");
		WebElement ele = locateElement("id", "username");
		enterValue(ele, "Bootcamp@123");
		return this;
	}

	public AppLauncher clickLogin() {
		// driver.findElement(By.name("Login")).click();
		
			
		clickElement(locateElement("name", "Login"));
		return new AppLauncher(driver);
	}
}
