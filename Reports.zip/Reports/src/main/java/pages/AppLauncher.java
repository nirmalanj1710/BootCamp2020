package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjCommMethods;

public class AppLauncher extends ProjCommMethods {

	public AppLauncher(RemoteWebDriver driver) {
		this.driver = driver;
		//this.prop = prop;
	}
	
	// AppLauncher
	public AppLauncher appLaunch() {
		driver.findElement(By.xpath("//*[contains(@class,'slds-icon-waffle_container')]")).click();
		System.out.println("App Launcher clicked successfully");
		return this;
	}

	// Clicking on ViewAll
	public AppLauncher viewAll() {
		driver.findElement(By.xpath("//div/lightning-button//*[contains(@class,'slds-button')]")).click();
		System.out.println("View All clicked successfully");
		return this;
	}

	// Clicking on Sales
	public Account sales() {
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
		System.out.println("Sales clicked successfully");
		return new Account(driver);
	}

}
