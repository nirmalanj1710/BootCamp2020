package learnReports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class LearnReportsV5 {

	public static void main(String[] args) {

		// File Level

		ExtentSparkReporter spark = new ExtentSparkReporter("./sparkReports/result.html");
		// ExtentSparkReporter spark1 = new
		// ExtentSparkReporter("./sparkReports/result1.html");

		ExtentReports ext = new ExtentReports();
		ext.attachReporter(spark);

		// TestCase Level - Create Account
		// TestCase name, Des, Author, Category, DeviceName

		ExtentTest createTest = ext.createTest("CreateAccount",
				"To create the account in Salesforce Accounts Module...");
		createTest.assignAuthor("Nirmalan");
		createTest.assignCategory("Regression");
		createTest.assignDevice("DellDesktop"); // used to perform during Mobile automation

		// Step Level
		// status for report level - Pass, Fail, Warning, info, skip
		createTest.pass("The salesforce login app entered successfully",
				MediaEntityBuilder.createScreenCaptureFromPath("./1.png").build());
		// createTest.pass("The salesforce login app entered successfully");
		createTest.pass("Successfully click on viewAll",
				MediaEntityBuilder.createScreenCaptureFromPath("./2.png").build());
		createTest.pass("Sales button is clicked", MediaEntityBuilder.createScreenCaptureFromPath("./3.png").build());

		// To write some logic for executing the report
		ext.flush();
	}
}
