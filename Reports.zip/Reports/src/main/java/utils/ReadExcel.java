package utils;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	// @SuppressWarnings({ "unchecked", "unchecked" })
	public static void main(String[] args) throws Exception {

		// to get into workbook
		XSSFWorkbook wb = new XSSFWorkbook("./data/CreateAccount.xlsx");

		// to get into worksheet
		XSSFSheet sheet = wb.getSheet("Sheet1");

		// to get into the worksheet using index
		// wb.getSheetAt(0);
		int lastRowNum = sheet.getLastRowNum();
		
		System.out.println(lastRowNum);

		for (int i = 0; i <= 5; i++) {
			for (int j = 0; j <= 5; j++) {
				String cellValue = sheet.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellValue);
			}

			/*
			 * // to get into the row XSSFRow row = sheet.getRow(i);
			 * 
			 * // to get into the cell XSSFCell cell = row.getCell(0);
			 * 
			 * // to read the data String cellValue = cell.getStringCellValue();
			 */
		wb.close();
		}
	}}

	
		/*
		 * // to get into the row XSSFRow row = sheet.getRow(i);
		 * 
		 * // to get into the cell XSSFCell cell = row.getCell(0);
		 * 
		 * // to read the data String cellValue = cell.getStringCellValue();
		 * System.out.println(cellValue);
		 */

		// to close the workbook