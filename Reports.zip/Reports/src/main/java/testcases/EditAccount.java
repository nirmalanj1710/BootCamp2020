package testcases;

import org.testng.annotations.Test;

import base.ProjCommMethods;
import pages.LoginPage;

public class EditAccount extends ProjCommMethods {

	@Test
	public void editAcc() throws InterruptedException {

		new LoginPage(driver)
		.enterPassword()
		.enterUsername()
		.clickLogin()
		.appLaunch()
		.viewAll()
		.sales()
		.clickAccount()
		.searchAcc()
		.clickDropDown()
		.clickEdit()
		.choseType()
		.choseIndustry()
		.enterBillingStreet()
		.enterShippingStreet()
		.choseCustPriority()
		.choseSla()
		.choseActive()
		.enterUniqueNum()
		.choseUpsellOpp()
		.saveButton();		
}
}
