package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjCommMethods;
import pages.LoginPage;

public class CreateAccount extends ProjCommMethods {
	
	@BeforeTest
	public void setFile() {
	excelFileName = "CreateAccount";
	}
	
	@Test
	//(dataProvider = "fetchData")
	public void creatAcc() throws InterruptedException {

		new LoginPage(driver, prop)
		.enterPassword()
		.enterUsername()
		.clickLogin()
		.appLaunch()
		.viewAll()
		.sales()
		.clickAccount()
		.newButton()
		.accountName()
		.ownership()
		.saveButton();
	}

}
