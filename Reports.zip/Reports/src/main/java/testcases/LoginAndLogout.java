package testcases;

import org.testng.annotations.Test;

import base.ProjCommMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjCommMethods {

	@Test
	public void loginTest() {

		//LoginPage lp = new LoginPage();

		new LoginPage(driver)
		.enterUsername()
		.enterPassword()
		.clickLogin();
	}

}
