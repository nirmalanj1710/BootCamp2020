package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class ProjCommMethods extends GenericWrapper {
	// public ChromeDriver driver; //remove static keyword to run parallel cases
	public String excelFileName;
	public Properties prop;

	// @Parameters({ "language" })
	@BeforeMethod
	public void startApp(String lang) throws IOException {

		// steps to load the properties file
		FileInputStream fis = new FileInputStream("./propertiesFile/" + lang + ".properties");
		prop = new Properties();
		prop.load(fis);

		launchBrowser("chrome", "https://login.salesforce.com");
	}

	@AfterMethod
	public void closeApp() {
		driver.close();
	}

	@DataProvider(name = "fetchData", indices = 0)
	public String[][] sendData() throws Exception {
		// String[][] readData = ReadExcel.readData(); // /* // * ReadExcel re = new
		ReadExcel re = new ReadExcel();
		String[][] readData = re.readData(excelFileName);
		return readData;

		// return ReadExcel.readData(excelFileName);
	}
}
