package base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GenericWrapper {
	public RemoteWebDriver driver;
	WebDriver wait;

	// report - snapshot, desc

	public void launchBrowser(String browser, String url) {

		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public WebElement locateElement(String locator, String locValue) {
		switch (locator) {
		case "id":
			return driver.findElementById(locValue);
		case "class":
			return driver.findElementByClassName(locValue);
		case "xpath":
			return driver.findElementByXPath(locValue);
		case "name":
			return driver.findElementByName(locValue);
		}
		return null;
	}

	public void enterValue(WebElement ele, String data) {
		// wait.until(ExpectedConditions.elementToBeClickable(ele));
		try {
			ele.sendKeys(data);
			System.out.println("pass");
		} catch (Exception e) {
			System.out.println("fail"); // need to call reporter function
		}
	}

	public void clickElement(WebElement ele) {
		ele.click();
	}

	// alert(accept,dismiss)
	// frame
	// windowHandles
	// assert verification

	public void selectValueIndex(WebElement ele, int index) {
// Select aa = new Select(ele);
// aa.selectByIndex(index);
		new Select(ele).selectByIndex(index);
	}
}
