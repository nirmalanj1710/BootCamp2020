package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hooks extends BaseClass {

	@Before
	public void preCondition() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://login.salesforce.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
//		driver.findElementById("username").sendKeys("cypress@testleaf.com");
//		driver.findElementById("password").sendKeys("Bootcamp@123");
//		driver.findElementById("username").sendKeys("hari.radhakrishnan@testleaf.com");
//        driver.findElementById("password").sendKeys("Newyorkcity@911");
		driver.findElementById("username").sendKeys("bowyakarthikeyan@testleaf.com");
		driver.findElementById("password").sendKeys("India@123");
		driver.findElement(By.name("Login")).click();
	}

	@After
	public void postCondition() {
		driver.close();
	}
}
