package steps;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class CreateReport extends BaseClass {
	String reportNameStore = "Nirmal02";
	
	@Then("load AppLauncher and navigate till Reports option")
	public void navReports() {
		navigateToReports();
	}

	@And("click on New Report_Salesforce_Classic")
	public void clickNewReport() {
		driver.findElement(By.xpath("//a[@title='New Report (Salesforce Classic)']")).click();
		System.out.println("New Report (Salesforce Classic) clicked successfully");
	}

	@And("click on Leads")
	public void clickLeads() {

		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='isEdit reportsReportBuilder']")));
		System.out.println("Frames switched ! ");

		driver.findElementByXPath(
				"//ul[@class='x-tree-root-ct x-tree-lines']//li/div/a[@class='x-tree-node-anchor']/span[text()='Leads']")
				.click();
		System.out.println("Leads button is clicked successfully");
	}

	@And("click on Lead Report image to download")
	public void clickLeadReportImg() throws MalformedURLException, IOException, InterruptedException {

		// WebElement imgElement = null;
		WebElement logo = driver.findElementByXPath("//table//td/div/div[@id='thePage:dummyForm:j_id34']");
		String logoSrc = logo.getAttribute("src");
		URL imageURL = new URL(logoSrc);
		BufferedImage bufferedImage = ImageIO.read(imageURL);
		File outputfile = new File("saved.png");
		ImageIO.write(bufferedImage, "png", outputfile);

		// WebElement Img =
		// driver.findElementByXPath("//table//td/div/div[@id='thePage:dummyForm:j_id34']");
//		Actions act = new Actions(driver);
//		act.contextClick(Img).sendKeys("v").perform();
//		Thread.sleep(2000);
//        
//        Runtime.getRuntime().exec("./downloads");
//        Thread.sleep(2000);
		/*
		 * Actions hover1 = builder1.moveToElement(element1);
		 * 
		 * act.sendKeys(Keys.CONTROL, "v").build().perform();
		 */
		System.out.println("Image saved successfully");
	}

	@And("click on Create button")
	public void clickCreate() {
		driver.findElementByXPath("//input[@value='Create']").click();
		System.out.println("Create button clicked successfully");
		driver.switchTo().defaultContent();
	}

	@And("select the Range as All Time")
	public void choseRange() throws InterruptedException {

		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='isEdit reportsReportBuilder']")));

		driver.findElement(By.xpath("(//div/img[@class='x-form-trigger x-form-arrow-trigger'])[3]")).click();
		Thread.sleep(2000);

		WebElement element = driver
				.findElement(By.xpath("//div[@class='x-layer x-combo-list ']//div[text()='All Time']"));
		Actions builder = new Actions(driver);
		Actions hover = builder.moveToElement(element);
		System.out.println("Mouse hoover succeed to 'All Time' option");
		hover.build().perform();
		Thread.sleep(2000);
		element.click();
		driver.switchTo().defaultContent();
		System.out.println("Range is selected successfully as 'All Time'");

	}

	@And("select the date as 5 days from today")
	public void choseDate() throws InterruptedException {
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='isEdit reportsReportBuilder']")));
		driver.findElement(By.xpath("//div/input[@name='endDate']")).sendKeys("2/21/2021");

		// String today = getCurrentDay();
//		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='isEdit reportsReportBuilder']")));
//
//		WebElement datedpdwm = driver
//				.findElement(By.xpath("(//div/img[@class='x-form-trigger x-form-date-trigger'])[2]"));
//		System.out.println("DateDropDown clicked successfully");
//		JavascriptExecutor executor = (JavascriptExecutor) driver;
//		executor.executeScript("arguments[0].click();", datedpdwm);
//		Thread.sleep(3000);
//
//		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
//		Calendar cal = Calendar.getInstance();
//		System.out.println(dateFormat.format(cal.getTime()));
//
//		cal.add(Calendar.DAY_OF_MONTH, +5);
//		System.out.println("Date : " + dateFormat.format(cal.getTime()));
//
//		WebElement element2 = driver.findElement(By.xpath("//tbody/tr[3]/td[7]"));
//		element2.click();
//		Actions builder2 = new Actions(driver);
//		Actions hover = builder2.moveToElement(element2);
//		System.out.println("Mouse hoover succeed to desired option in web table");
//		hover.build().perform();
//		element2.click();

		/*
		 * List<WebElement> allDates =
		 * driver.findElements(By.xpath("//tbody/tr[3]/td[7]"));
		 * System.out.println(allDates); for (WebElement ele : allDates) { { if
		 * (ele.getText().trim().equals(19)) { ele.click(); break; } } }
		 */

	}

	public void systemTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		Calendar cal = Calendar.getInstance();
		System.out.println(dateFormat.format(cal.getTime()));
	}

	public String getCurrentDay() {
		// Create a Calendar Object
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());

		// Get Current Day as a number
		int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
		System.out.println("Today Int: " + todayInt + "\n");

		// Integer to String Conversion
		String todayStr = Integer.toString(todayInt);
		System.out.println("Today Str: " + todayStr + "\n");

		return todayStr;
	}

	@And("veriy the Preview is in Tabular Format")
	public void verifyTabularFormat() {
		driver.findElementByXPath("//td/table[@id='reportFormatMink']").click();

		WebElement element1 = driver.findElement(By.xpath("//div//span[text()='Tabular']"));
		Actions builder3 = new Actions(driver);
		Actions hover = builder3.moveToElement(element1);
		hover.build().perform();
		element1.click();

		System.out.println("Tabular option is selected successfully");
	}

	@And("get the List of Company_Account")
	public void compAcc() {
		List<WebElement> allRows = driver.findElements(By.xpath(
				"//table[@class='x-grid3-row-table']//td[@class='x-grid3-col x-grid3-cell x-grid3-td-COMPANY ']"));

		ArrayList<String> arrayList = new ArrayList<String>();

		for (WebElement e : allRows) {
			arrayList.add(e.getText());
		}
		System.out.println("The list of Company accounts available are: " +arrayList);

		// int rowCount = allRows.size();

		// System.out.println("Total number of rows available are: " +rowCount);
	}

	@And("get the Grand Total of Records Available")
	public void totRecCount() {
		List<WebElement> allRows = driver.findElements(By.xpath(
				"//table[@class='x-grid3-row-table']//td[@class='x-grid3-col x-grid3-cell x-grid3-td-COMPANY ']"));
		int rowCount = allRows.size();
		System.out.println("Total number of rows available are: " + rowCount);

	}

	@Then("click on save button in Reports")
	public void clickSaveRep() {
		driver.findElement(By.xpath("//tbody//td//button[@type='button']")).click();
		System.out.println("Save button is clicked successfully !! ");
	}

	@And("Enter Report name as Nirmal")
	public void reportName() {
		
		driver.findElementByXPath("//input[@name='reportName']").sendKeys(reportNameStore);
		System.out.println("Report name entered .. ");
		
	}

	@And("Enter Report Unique name as Nirmal_01")
	public void reportUniqueName() {
		driver.findElementByXPath("//input[@name='reportDevName']").sendKeys("Nirmal_02");
		System.out.println("Unique report name entered ...");
	}

	@And("Report Discussion as Report Updated by Nirmal01")
	public void reportDiscuss() {
		driver.findElementByXPath("//textarea[@name='reportDescription']").sendKeys("Report Updated by Nirmal02");
		System.out.println("Report discussion is updated ....");
	}

	@And("select Report Folder as Unfiled Public Reports")
	public void reportFolder() throws InterruptedException {

		driver.findElement(
				By.xpath("//div[@class='x-form-element']//div/img[@class='x-form-trigger x-form-arrow-trigger']"))
				.click();
		Thread.sleep(2000);

		WebElement ele = driver.findElement(By.xpath("(//div[@class='x-combo-list-item x-combo-selected'])[2]"));
		Actions build = new Actions(driver);
		Actions hover = build.moveToElement(ele);
		hover.build().perform();
		ele.click();
		System.out.println("'Unfiled Public Reports' is selected successfully");
	}

	@Then("click save button to save the Reports")
	public void clickSaveInReports() {
		driver.findElement(By.xpath("//table[@id='dlgSaveReport']//td//button[@type='button']")).click();
		System.out.println("Save button clicked and reports saved successfully");
	}

	@And("Verify Report has been created successfully")
	public void verReportName() {
		
		driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[@class='isEdit reportsReportBuilder'])[2]")));
		System.out.println("Switched to Frames ! ");
		
		WebElement value = driver.findElement(By.xpath("//div[@class=' x-border-panel']//div[@class='bPageTitle']/div/div[@class='content']/h2"));
		
		//WebElement value = driver.findElement(By.xpath("string(/*/div[@class='content']/h2/@class)"));
		System.out.println("Name of the report created: "+value);
		//if(reportNameStore != value)
		driver.switchTo().defaultContent();		
	}
	
	@And("Click on Run Report")
	public void clickRunReport() {
		driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[@class='isEdit reportsReportBuilder'])[2]")));
		System.out.println("Switched to Frames ! ");
		
		
	}
	
	public void cickEdit() {

	}
}
