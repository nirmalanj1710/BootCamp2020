package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.And;

public class EditAccount extends BaseClass {

	@And("click on search box and enter search text")
	public void searchText() throws InterruptedException {
		WebElement Post;
		Post = driver.findElement(By.xpath("//*[contains(@placeholder, 'Search this list...')]"));
		Post.sendKeys("Nirmalan");
		Post.click();
		System.out.println("Clicked on search button and searched for the required account name successfully");

		// to filter the result, trying to click on the page as we don't have an enter
		// button
		driver.findElement(By.xpath("//li//span[text()='Accounts']")).click();
		Thread.sleep(4000);
	}

	@And("click on DropDown")
	public void clickDropDown() throws InterruptedException {
		driver.findElement(By.xpath("//tr//td[@class='slds-cell-edit cellContainer']/following::a[@role='button']"))
				.click();
		Thread.sleep(6000);
	}

	@And("click on EditOption")
	public void clickEditOpt() {
		WebElement element = driver
				.findElement(By.xpath("//div[@class='branding-actions actionMenu']//following::a/div[@title='Edit']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(element).click().perform();
		System.out.println("Edit option clicked succcssfully from the drop down");
	}

	@And("choosing the value Type as Technology Partner")
	public void choseType() {
		driver.findElement(By.xpath(
				"(//div[@class='slds-form-element slds-hint-parent']/following::div[@class='uiMenu']//a[text()='--None--'])[1]"))
				.click();

		WebElement ele1 = driver
				.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Technology Partner']"));
		Actions builder1 = new Actions(driver);
		Actions hover1 = builder1.moveToElement(ele1);
		System.out.println("Mouse hoover succeed to Technology Partner option");
		hover1.build().perform();

		ele1.click();
		System.out.println("Type value is selected successfully as Technology Partner");
	}

	@And("choosing the value Industry as Healthcare")
	public void choseIndustry() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Industry']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele2 = driver
				.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Healthcare']"));
		Actions builder2 = new Actions(driver);
		Actions hover2 = builder2.moveToElement(ele2);
		System.out.println("Mouse hoover succeed to Healthcare option");
		hover2.build().perform();
		ele2.click();
		System.out.println("Industry value is selected successfully as Healthcare");
	}

	@And("Enter the details for Billing Street as (.*)")
	public void enterBillStreet(String billAdd) {
		driver.findElement(By.xpath("//*[contains(@placeholder,'Billing Street')]")).sendKeys(billAdd);
		System.out.println("Details are successfully entered in Billing Street");
	}

	@And("Enter the details for Shipping Street as (.*)")
	public void enterShipStreet(String shipAdd) {
		driver.findElement(By.xpath("//*[contains(@placeholder,'Shipping Street')]")).sendKeys(shipAdd);
		System.out.println("Details are successfully entered in Shipping Street");
	}

	@And("choosing the value Customer Priority as Low")
	public void choseCustPriority() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Customer Priority']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele3 = driver.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Low']"));
		Actions builder3 = new Actions(driver);
		Actions hover3 = builder3.moveToElement(ele3);
		System.out.println("Mouse hoover succeed to Low option");
		ele3.click();
		System.out.println("Customer Priority value is selected successfully as Low");
	}

	@And("choosing the value SLA as Silver")
	public void choseSla() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='SLA']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Silver']"));
		Actions builder4 = new Actions(driver);
		Actions hover4 = builder4.moveToElement(ele4);
		hover4.build().perform();
		System.out.println("Mouse hoover succeed to Silver option");
		ele4.click();
		System.out.println("SLA value is selected successfully as Silver");
	}

	@And("choosing the value Active as NO")
	public void choseActive() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Active']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele5 = driver.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='No']"));
		Actions builder5 = new Actions(driver);
		Actions hover5 = builder5.moveToElement(ele5);
		System.out.println("Mouse hoover succeed to No option ");
		hover5.build().perform();
		ele5.click();
		System.out.println("Active value is selected successfully as NO");
	}

	@And("Enter the details for Unique Number in Phone Field as (.*)")
	public void enterUniqueNum(CharSequence[] phNum) {
		driver.findElement(By.xpath(
				"//label[@class='label inputLabel uiLabel-left form-element__label uiLabel']//span[text()='Phone']/following::input[1]"))
				.sendKeys(phNum);
		System.out.println("Details are successfully entered in Unique Number field");
	}

	@And("choosing the value Upsell Opportunity as No")
	public void choseUpsellOpp() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Upsell Opportunity']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele6 = driver
				.findElement(By.xpath("(//div[@class='select-options']//ul[@class='scrollable']//a[text()='No'])[2]"));
		Actions builder6 = new Actions(driver);
		Actions hover6 = builder6.moveToElement(ele6);
		System.out.println("Mouse hoover succeed to No option");
		hover6.build().perform();
		ele6.click();
		System.out.println("Upsell Opportunity is selected successfully as No");
	}

}
