package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.And;

public class DeleteAccount extends BaseClass {

	@And("click on DeleteOption")
	public void clickDelOpt() {
		WebElement element = driver.findElement(
				By.xpath("//div[@class='branding-actions actionMenu']//following::a/div[@title='Delete']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(element).click().perform();
		System.out.println("Delete option clicked succcssfully from the drop down");
	}

	@And("click on delete button")
	public void clicDel () {
		clickDelete();	
	}
	
}
