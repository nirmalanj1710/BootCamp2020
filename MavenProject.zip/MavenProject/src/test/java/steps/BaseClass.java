package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {

	public static ChromeDriver driver;

	public void navigateToAccounts() {

		driver.findElement(By.xpath("//*[contains(@class,'slds-icon-waffle_container')]")).click();
		System.out.println("App Launcher clicked successfully");

		driver.findElement(By.xpath("//div/lightning-button//*[contains(@class,'slds-button')]")).click();
		System.out.println("View All clicked successfully");

		driver.findElement(By.xpath("//p[text()='Sales']")).click();
		System.out.println("Sales clicked successfully");

		WebElement accdpdwm = driver.findElement(By.xpath("//a[@title='Accounts']"));
		System.out.println("Accounts clicked successfully");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", accdpdwm);
		System.out.println("Navigated till Accounts tab successfully");
	}

	
	public void navigateToReports() {
		driver.findElement(By.xpath("//*[contains(@class,'slds-icon-waffle_container')]")).click();
		System.out.println("App Launcher clicked successfully");

		driver.findElement(By.xpath("//div/lightning-button//*[contains(@class,'slds-button')]")).click();
		System.out.println("View All clicked successfully");

		driver.findElement(By.xpath("//p[text()='Service']")).click();
		System.out.println("Service clicked successfully");

		WebElement accdpdwm = driver.findElement(By.xpath("//a[@title='Reports']"));
		System.out.println("Reports clicked successfully");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", accdpdwm);
		System.out.println("Navigated till Reports tab successfully");
	}
	
	
	public void clickSave() {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		System.out.println("SAVE button clicked successfully");
	}
	
	

	
	public void clickDelete() {
		driver.findElement(By.xpath("//button[@class='slds-button slds-button--neutral uiButton--default uiButton--brand uiButton forceActionButton']//following::span[text()='Delete']")).click();
		System.out.println("Delete button is clicked successfully !!!");	
	}
}
