package learnings;

public class MyCar {

	public static void main(String[] args) {

		Car ut = new Car();

		String st = ut.carControl();
		System.out.println(st);

	}

}
