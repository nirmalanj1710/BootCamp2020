package learnings;

public class Person {
 static int z=2;
	private void eat() {
		System.out.println("This is a non static method");
		System.out.println(this.z);
	}

	private static void sleep() {
		System.out.println("This is a STATIC method");
		
	}

	public static void main(String[] args) {
		Person.sleep();
		Person ls = new Person();
		ls.eat();
		
		String a="5";
		String b="5";
	
		int m = Integer.parseInt(a);
		int n = Integer.parseInt(b);
		System.out.println(m+n);
	}
	
	

}
