package learnings;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class CalendarSample {

//	
//	public static String getCurrentDay (){
//        //Create a Calendar Object
//        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
// 
//        //Get Current Day as a number
//        int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
//        System.out.println("Today Int: " + todayInt +"\n");
// 
//        //Integer to String Conversion
//        String todayStr = Integer.toString(todayInt);
//        System.out.println("Today Str: " + todayStr + "\n");
// 
//        return todayStr;
//    }
	
	public static void main(String[] args) {
//		String today = getCurrentDay();
//		System.out.println(today);
		
		 DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		 Calendar cal = Calendar.getInstance();
		 System.out.println(dateFormat.format(cal.getTime()));
		 
		 
//		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy MMM dd");	
//	        
//     	 Calendar calendar = new GregorianCalendar(2013,10,28);	
//	     System.out.println("Date : " + sdf.format(calendar.getTime()));

//		 //add one month
//		 cal.add(Calendar.MONTH, 1);
//		 System.out.println("Date : " + dateFormat.format(cal.getTime()));
//		        
		 //subtract 10 days
//		 cal.add(Calendar.DAY_OF_MONTH, -10);
//		 System.out.println("Date : " + dateFormat.format(cal.getTime()));
         
		 //add 5 days
		 cal.add(Calendar.DAY_OF_MONTH, +5);
		 System.out.println("Date : " + dateFormat.format(cal.getTime()));
		 
	}
	
}
