package learnings;

public class Car {

	public String carControl() {

		String a = "Steering";
		String b = "Gear";
		return "published the capabilities";
	}

	private boolean startOrClose(){
		System.out.println("Car started");
		return true;
		
	}
}
