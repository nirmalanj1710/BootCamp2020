package learnings;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.formula.SheetIdentifier;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadLearning {

	public static void main(String[] args) throws IOException {

		FileInputStream fs = new FileInputStream("C:\\Users\\cseni\\Desktop\\sample.xlsx");
		
		XSSFWorkbook wb = new XSSFWorkbook(fs);
		XSSFSheet Sheet1 = wb.getSheetAt(0);
		/*
		 * Row row = Sheet1.getRow(0); Cell cell = row.getCell(0);
		 * System.out.println(cell); System.out.println(Sheet1.getRow(0).getCell(0));
		 * 
		 * Row row1 = Sheet1.getRow(1); Cell cell1 = row1.getCell(1);
		 * System.out.println(Sheet1.getRow(0).getCell(1));
		 */
		
		Row row2 = Sheet1.getRow(1);
		Cell cell2 = row2.getCell(0);
		System.out.println(Sheet1.getRow(1).getCell(0));
		
		Row row3 = Sheet1.getRow(1);
		Cell cell3 = row3.getCell(1);
		System.out.println(Sheet1.getRow(1).getCell(1));
		
		Row row4 = Sheet1.getRow(2);
		Cell cell4 = row4.getCell(0);
		System.out.println(Sheet1.getRow(2).getCell(0));
		

	}

}
