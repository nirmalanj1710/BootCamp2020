package learnings;

public class LearningSum {
	int c = 3;

	public static void main(String[] args) {

		LearningSum ls = new LearningSum();
		ls.addSum(5, 10);

	}

	public void addSum(int a, int b) {
		int c = 2;
		System.out.println(a + b + this.c);
		System.out.println(c);

	}
}
