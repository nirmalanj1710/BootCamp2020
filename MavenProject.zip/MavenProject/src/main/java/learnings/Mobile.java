package learnings;

public class Mobile {

	public static void main(String[] args) {

		Mobile mm = new Mobile();
		mm.myName("Nirmal");
		mm.myName(787846);
		mm.myNum();
	}

	public void myName(String s) {
		System.out.println("Name is:  " + s);
	}

	public void myName(int s) {
		System.out.println("Name is:  " + s);
	}

	private void myNum() {
		System.out.println("Mobile number is secret");
	}
}
