package learnings;

public class YouTube {

	public static void main(String[] args) {


		PractiseFun yt = new PractiseFun();
		//yt.createVideo();
		
		
		String sh = yt.sharedVideo();
		
		System.out.println(sh);
		
		
		
		
		
	}

}
