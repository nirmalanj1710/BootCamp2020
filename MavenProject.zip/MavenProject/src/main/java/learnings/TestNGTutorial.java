package learnings;

import org.testng.annotations.Test;

public class TestNGTutorial {

	@Test	
	public void SampleSetup() {
		System.out.println("YouTuber creates a video");
	}

	

}
