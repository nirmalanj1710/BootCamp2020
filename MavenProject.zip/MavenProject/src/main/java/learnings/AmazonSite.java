package learnings;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.sql.Driver;
import java.time.Duration;
import java.util.function.Function;

import javax.swing.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonSite {
	public static RemoteWebDriver driver;
	static WebDriverWait wait;

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();

		// WebDriver driver;
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		String title = driver.getTitle();
		System.out.println(title);

//		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone");
		// driver.findElement(By.id("nav-search-submit-button")).click();

		// WebElement ele = driver.findElement(By.id("p_89/Apple"));
		// wait.until(ExpectedConditions.visibilityOf(ele));

//		wait.until(ExpectedConditions.elementToBeClickable(ele));
//		ele.click();
//		System.out.println(ele);

		driver.findElementByXPath("//div//form/div[@class='nav-left']").click();
		Thread.sleep(2000);
		WebElement soft = driver.findElement(By.xpath("//div/select/option[text()='Software']"));

		Actions build1 = new Actions(driver);
		Action mouseHover = (Action) build1.moveToElement(soft).build();
		((Actions) mouseHover).perform();
				
				
				
		
			
	}

}
