package learnings;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LetCode {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://letcode.in/dropdowns");

		WebElement element = driver.findElement(By.id("fruits"));
		element.click();
		Thread.sleep(3000);
		//Actions act = new Actions(element);
		
		//act.moveToElement("//select[@id='fruits']//option['Apple'][2]");
		
		//act.build().perform();
		
		
		
        System.out.println(element);
		
	}

}


		