package learnings;

import org.apache.commons.math3.analysis.function.Add;

public class PractiseFun {
	public static void main(String[] args) {

		PractiseFun sm = new PractiseFun();
		sm.deleteVideo("whfwier77");
		sm.deleteVideo(15465);
	}

	public void createVideo(int a) {
		System.out.println("Video created " + a);
	}

	private boolean uploadVideo() {
		System.out.println("Uploading video done !!");
		return true;
	}

	public String sharedVideo() {
		return "orkut";
	}

	private void deleteVideo(String videoID) {
		System.out.println("Deleted Video " + videoID);

	}
	private void deleteVideo(int a) {
		System.out.println("Deleted Video " + a);

	}
	
}
