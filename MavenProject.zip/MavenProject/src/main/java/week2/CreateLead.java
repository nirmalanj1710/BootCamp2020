package week2;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;


public class CreateLead {

	final static String url = "https://login.salesforce.com";
	final static String uid = "cypress@testleaf.com";
	final static String pwd = "Bootcamp@123";
	final static String campaign_Name = "Bootcamp_Nirmal";
	
	
	public static void main(String[] args) {
		//Automation for Create Campaign S20-51	
				//WebDriver Initialization
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				
				WebDriverManager.chromedriver().setup();
				WebDriver driver = new ChromeDriver(options);
				
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
				
			//1. Login to https://login.salesforce.com
			//********************************************************
				
				//Launch SF
				driver.get(url);
				driver.manage().window().maximize();

				
				//Enter SF login username
				driver.findElement(By.id("username")).click();
				driver.findElement(By.id("username")).clear();
				driver.findElement(By.id("username")).sendKeys(uid);
				
				//Enter SF login password
				driver.findElement(By.id("password")).click();
				driver.findElement(By.id("password")).clear();
				driver.findElement(By.id("password")).sendKeys(pwd);
				
				//Click login button
				driver.findElement(By.id("Login")).click();

				//Wait for the Home screen to load.
				try {Thread.sleep(10000);} catch (InterruptedException e) {e.printStackTrace();}
				
				//Verify the display of HomeScreen.
				String title = driver.getTitle();
				System.out.println("Title : "+title);
				
				 SoftAssert s_assert = new SoftAssert();
				 s_assert.assertEquals(title, "Home | Salesforce");		 
				 
				
			//2. Click on the toggle menu button from the left corner
			//********************************************************
				driver.findElement(By.xpath("//div[@class='appLauncher slds-context-bar__icon-action']")).click();;
				System.out.println("Toggle clicked successfully");
				try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
				
			
			//3. Click View All and click Sales from App Launcher
			//********************************************************
				driver.findElement(By.xpath("//button[contains(text(),'View All')]/parent::lightning-button")).click();;
				System.out.println("ViewAll clicked successfully");
				try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}

				//Click on Sales link
				driver.findElement(By.xpath("//p[text()='Sales']")).click();
				try {Thread.sleep(8000);} catch (InterruptedException e) {e.printStackTrace();}
				System.out.println("Sales clicked successfully");
				

			//4. Click on the Campaigns tab 
			//*******************************************************	
				WebElement element = driver.findElement(By.xpath("//a[@title='Campaigns']"));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", element);
				System.out.println("Campaigns tab clicked successfully");
				try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
				
			//5. Click the Bootcamp link
			//*******************************************************
				List<WebElement> accountName = driver.findElements(By.xpath("//table[@data-aura-class='uiVirtualDataTable']//following-sibling::tbody/tr/th/span/a"));
				
				for (WebElement an : accountName) {
					String acc = an.getText();		
					if (acc.contentEquals("Bootcamp_Nirmal"))
					{
						an.click();
						System.out.println("Bootcamp link clicked successfully");
						break;
					}
				}
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
					
				
			//6. Click Add Leads
			//*******************************************************
				
				executor.executeScript("window.scrollBy(0,300)");
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
				
				Actions action = new Actions(driver);
				WebElement ele_NO = driver.findElement(By.xpath("//a[@role = 'button'][@title = 'Add Leads']"));
				action.moveToElement(ele_NO).click().perform();		
				
				System.out.println("Campaign Members > Add Leads button clicked successfully");
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}	
				
				Date rawexpDate = new Date(new Date().getTime());
				String salut = "Mr";
				String fname = "Lead Nirmal";
				String lname = "J " + rawexpDate;
				String cname = "Test Leaf";
			
				//7. Click on New Lead
				//*******************************************************
				driver.findElement(By.xpath("(//div[@data-aura-class='forceSearchInputLookupDesktopActionItem'])[2]")).click();
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}		
				
				//8. Pick Salutation as 'Mr.'
				//*******************************************************
				driver.findElement(By.xpath("//a[@class='select'][text()='--None--']")).click();
				try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
				
				String xPath = "//li[@role='presentation']/a[text()='"+salut+".']";
				driver.findElement(By.xpath(xPath)).click();
						  
				
				//9. Enter the first name as <your First Name>
				//*******************************************************
				driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(fname);
				try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}

				
				//10. Enter the last name as <your last name>
				//*******************************************************		
				driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lname);
				try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
				
				
				//11. Enter company as 'TestLeaf'
				//*******************************************************	
				driver.findElement(By.xpath("//span[text()='Company']/parent::label/following-sibling::input")).sendKeys(cname);
				try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
				
				
				//12. Click Save
				//*******************************************************
				driver.findElement(By.xpath("//button[@title='Save']")).click();
				System.out.println("Lead saved successfully");
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}	
				
				
				//13. Click Next
				//*******************************************************
				driver.findElement(By.xpath("//span[text()='Next']/parent::button")).click();;
				System.out.println("Next clicked successfully");
				try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}	
				
				
//				14. Click Submit on the Add to Campaign pop up
				//*******************************************************
				driver.findElement(By.xpath("//span[text()='Submit']/parent::button")).click();;
				System.out.println("Submit clicked successfully");
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}	
				
//				15. verify the created Lead under Campaign
				//*******************************************************
				
				executor.executeScript("window.scrollBy(0,600)");
				try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
				
				String confi = driver.findElement(By.xpath("//div[@role='alert'][@data-key='success']//div[@class='toastTitle slds-text-heading--small']")).getText();
				System.out.println(confi);
				
				WebElement ele_VA = driver.findElement(By.xpath("(//div[@class='slds-card__footer']//span[@class='view-all-label'])[2]"));
				action.moveToElement(ele_VA).click().perform();		
				
				System.out.println("Campaign Members - View All link clicked successfully");
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}	
				
				
				List<WebElement> tabRow = driver.findElements(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody/tr"));
				int initTabRowCount = tabRow.size();
				int flag = 0;
				
				if (initTabRowCount < 1)
					System.out.println("There are no Leads added to list");
				else
				{
					List<WebElement> tabDropdown = driver.findElements(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'][@role='grid']/tbody)[2]/tr/th"));
					for(WebElement dd : tabDropdown)
					{
						String extfname = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable']/tbody)[2]/tr/td[4]/span/a")).getText();
						String extlname = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable']/tbody)[2]/tr/td[5]/span/a")).getText();
						String extcname = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable']/tbody)[2]/tr/td[7]/span/span[@data-aura-class='uiOutputText']")).getText();
						
						if ((fname.contentEquals(extfname)) && (lname.contentEquals(extlname)) && (cname.contentEquals(extcname)))
						{	
							System.out.println("Lead created successfully with details, "+fname+ " ; "+lname+" ; "+cname+".");
							flag = 1;
							break;
						}
							
					}
					if (flag == 0) 
					System.out.println("Lead creation is unsuccessful. Observed non matching lead details.");

				}
				
				
				//16. Navigate to the Leads tab
				//*******************************************************
				element = driver.findElement(By.xpath("//a[@title='Leads']"));
				executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", element);
				System.out.println("Leads tab clicked successfully");
				try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
				
				
				//17. Search for Lead with your Name
				//*******************************************************
				driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lname);
				driver.findElement(By.xpath("//button[@name = 'refreshButton'][@title='Refresh']")).click();
				try {Thread.sleep(10000);} catch (InterruptedException e) {e.printStackTrace();}
				
				String leadName = fname+" "+lname;
				flag = 0;
				List<WebElement> lattabRow = driver.findElements(By.xpath("//table[@data-aura-class='uiVirtualDataTable']//following-sibling::tbody/tr/th/span/a"));
					
				if (driver.findElement(By.xpath("//div[@class='listViewContent slds-table--header-fixed_container']/div[2]/div/p")).getText().contentEquals("No items to display."))
				{	
					System.out.println(driver.findElement(By.xpath("//div[@class='listViewContent slds-table--header-fixed_container']/div[2]/div/p")).getText());
					System.out.println("Lead, '"+leadName+"' not listd in main Lead page");
				}
				else
				{
					for (WebElement opn : lattabRow )
					{
						if(opn.getText().contentEquals(leadName))
						{
							System.out.println("Lead, '"+leadName+"' which was created in Campaign, is listed in main Lead page");
							flag = 1;
							break;
						}
					}
					if (flag == 0)
					{
						System.out.println("Lead, '"+leadName+"' not listd in main Lead page");
					}
				}

	}

}
