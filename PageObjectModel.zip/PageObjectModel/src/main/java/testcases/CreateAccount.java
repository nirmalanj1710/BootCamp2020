package testcases;

import org.testng.annotations.Test;

import base.ProjCommMethods;
import pages.LoginPage;

public class CreateAccount extends ProjCommMethods {
	
	
	@Test
	public void creatAcc() throws InterruptedException {

		new LoginPage(driver)
		.enterPassword()
		.enterUsername()
		.clickLogin()
		.appLaunch()
		.viewAll()
		.sales()
		.clickAccount()
		.newButton()
		.accountName()
		.ownership()
		.saveButton();
	}

}
