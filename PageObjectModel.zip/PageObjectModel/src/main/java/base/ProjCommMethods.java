package base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjCommMethods {
	public ChromeDriver driver; //remove static keyword to run parallel cases


	@BeforeMethod
	public void startApp() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@AfterMethod
	public void closeApp() {
		driver.close();
	}
	
//	@DataProvider(name = "fetchData", indices = 0)
//	public String [][] sendData (){
//		return ReadExcel.readData(excelFileName);
//		
//	}
}
