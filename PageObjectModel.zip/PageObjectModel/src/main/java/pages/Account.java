package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import base.ProjCommMethods;

public class Account extends ProjCommMethods {

	public Account(ChromeDriver driver) {
		this.driver = driver;
	}

	// Clicking on Accounts
	public Account clickAccount() {
		WebElement accdpdwm = driver.findElement(By.xpath("//a[@title='Accounts']"));
		System.out.println("Accounts clicked successfully");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", accdpdwm);
		return this;
	}

	// Clicking on New button
	public Account newButton() {
		driver.findElement(By.xpath("//a[@title='New']")).click();
		System.out.println("New button clicked successfully");
		return this;
	}

	// Entering the Account Name
	public Account accountName() {
		driver.findElement(By.xpath("//label//span[text()='Account Name']/following::input[1]")).sendKeys("DUMMY");
		System.out.println("Name is entered successfully as DUMMY");
		return this;
	}

	// Entering the Ownership
	// Selecting the value for Ownership as Public
	public Account ownership() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div//span[text()='Ownership']/following::a[1]")).click();

		driver.findElement(By.xpath("//div//a[text()='Public']")).click();
		System.out.println("Ownership is entered successfully as Public");
		return this;
	}

	// Search for the Account
	// to filter the result, trying to click on the page as we don't have an enter
	// button
	public Account searchAcc() throws InterruptedException {
		WebElement Post;
		Post = driver.findElement(By.xpath("//*[contains(@placeholder, 'Search this list...')]"));
		Post.sendKeys("DUMMY");
		Post.click();
		System.out.println("Clicked on search button and searched for the required account name successfully");

		driver.findElement(By.xpath("//li//span[text()='Accounts']")).click();
		Thread.sleep(3000);
		return this;
	}

	// To click on the drop down arrow
	public Account clickDropDown() {
		driver.findElement(By.xpath("//tr//td[@class='slds-cell-edit cellContainer']/following::a[@role='button']"))
				.click();
		return this;
	}

	// To click on the Edit option
	public Account clickEdit() {
		WebElement element = driver
				.findElement(By.xpath("//div[@class='branding-actions actionMenu']//following::a/div[@title='Edit']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(element).click().perform();
		System.out.println("Edit option clicked succcssfully from the drop down");
		return this;
	}

	// Selecting the value for Type as Technology Partner
	public Account choseType() {
		driver.findElement(By.xpath(
				"(//div[@class='slds-form-element slds-hint-parent']/following::div[@class='uiMenu']//a[text()='--None--'])[1]"))
				.click();

		WebElement ele1 = driver
				.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Technology Partner']"));
		Actions builder1 = new Actions(driver);
		Actions hover1 = builder1.moveToElement(ele1);
		System.out.println("Mouse hoover succeed to Technology Partner option");
		hover1.build().perform();

		ele1.click();
		System.out.println("Type value is selected successfully as Technology Partner");
		return this;
	}

	// Selecting the value for Industry as Healthcare
	public Account choseIndustry() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Industry']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele2 = driver
				.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Healthcare']"));
		Actions builder2 = new Actions(driver);
		Actions hover2 = builder2.moveToElement(ele2);
		System.out.println("Mouse hoover succeed to Healthcare option");
		hover2.build().perform();

		ele2.click();
		System.out.println("Industry value is selected successfully as Healthcare");
		return this;
	}

	// Entering the details for Billing Street
	public Account enterBillingStreet() {
		driver.findElement(By.xpath("//*[contains(@placeholder,'Billing Street')]")).sendKeys("TEST");
		System.out.println("Details are successfully entered in Billing Street");
		return this;
	}

	// Entering the details for Shipping Street

	public Account enterShippingStreet() {
		driver.findElement(By.xpath("//*[contains(@placeholder,'Shipping Street')]")).sendKeys("TEST");
		System.out.println("Details are successfully entered in Shipping Street");
		return this;
	}

	// Selecting the value for Customer Priority as Low
	public Account choseCustPriority() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Customer Priority']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele3 = driver.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Low']"));
		Actions builder3 = new Actions(driver);
		Actions hover3 = builder3.moveToElement(ele3);
		System.out.println("Mouse hoover succeed to Low option");

		ele3.click();
		System.out.println("Customer Priority value is selected successfully as Low");
		return this;
	}

	// Selecting the value for SLA as Silver
	public Account choseSla() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='SLA']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='Silver']"));
		Actions builder4 = new Actions(driver);
		Actions hover4 = builder4.moveToElement(ele4);
		hover4.build().perform();
		System.out.println("Mouse hoover succeed to Silver option");
		ele4.click();
		System.out.println("SLA value is selected successfully as Silver");
		return this;
	}

	// Selecting the value for Active as NO
	public Account choseActive() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Active']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele5 = driver.findElement(By.xpath("//div[@class='select-options']//ul//li//a[text()='No']"));
		Actions builder5 = new Actions(driver);
		Actions hover5 = builder5.moveToElement(ele5);
		System.out.println("Mouse hoover succeed to No option ");

		hover5.build().perform();
		ele5.click();
		System.out.println("Active value is selected successfully as NO");
		return this;
	}

	// Entering the details for Unique Number in Phone Field
	public Account enterUniqueNum() {
		driver.findElement(By.xpath(
				"//label[@class='label inputLabel uiLabel-left form-element__label uiLabel']//span[text()='Phone']/following::input[1]"))
				.sendKeys("7894563690");
		System.out.println("Details are successfully entered in Unique Number field");
		return this;
	}

	// Selecting the value for Upsell Opportunity as No
	public Account choseUpsellOpp() {
		driver.findElement(By.xpath(
				"//div[@class='slds-form-element slds-hint-parent']//span[text()='Upsell Opportunity']/following::a[text()='--None--'][1]"))
				.click();

		WebElement ele6 = driver
				.findElement(By.xpath("(//div[@class='select-options']//ul[@class='scrollable']//a[text()='No'])[2]"));
		Actions builder6 = new Actions(driver);
		Actions hover6 = builder6.moveToElement(ele6);
		System.out.println("Mouse hoover succeed to No option");
		hover6.build().perform();

		ele6.click();
		System.out.println("Upsell Opportunity is selected successfully as No");
		return this;
	}

	// To click on the Delete option
	public Account clickDelete() {
		WebElement element = driver.findElement(
				By.xpath("//div[@class='branding-actions actionMenu']//following::a/div[@title='Delete']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(element).click().perform();
		System.out.println("Delete option clicked succcssfully from the drop down");
		return this;
	}

	// Clicking on the Delete button
	public Account deleteButton() {
		driver.findElement(By.xpath(
				"//button[@class='slds-button slds-button--neutral uiButton--default uiButton--brand uiButton forceActionButton']//following::span[text()='Delete']"))
				.click();
		System.out.println("Delete button is clicked successfully !!!");
		return this;
	}

	// Click on Save button
	public Account saveButton() {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		System.out.println("SAVE button clicked successfully");
		return null;
	}
	
	
}
