package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjCommMethods;

public class LoginPage extends ProjCommMethods{
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public LoginPage enterUsername() {
		driver.findElementById("username").sendKeys("cypress@testleaf.com");
		return this;
	}

	public LoginPage enterPassword() {
		driver.findElementById("password").sendKeys("Bootcamp@123");
		return this;
	}
	
	public AppLauncher clickLogin() {
		driver.findElement(By.name("Login")).click();
		return new AppLauncher(driver);
	}
}
